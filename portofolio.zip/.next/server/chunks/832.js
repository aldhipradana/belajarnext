"use strict";
exports.id = 832;
exports.ids = [832];
exports.modules = {

/***/ 832:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Layout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./components/Header/index.tsx


function Header() {
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("header", {
            className: "container mx-auto",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                className: "flex flex-row justify-end text-white px-4 bg-slate-800 rounded-br-xl rounded-bl-xl drop-shadow-xl",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        className: "list-none ",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                            href: "/",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: "menu-item",
                                children: " Home "
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        className: "list-none",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                            href: "/blog",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: "menu-item",
                                children: " Blog "
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        className: "list-none",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                            href: "/about",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: "menu-item",
                                children: " About "
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        className: "list-none",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                            href: "/users",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: "menu-item",
                                children: " Users "
                            })
                        })
                    })
                ]
            })
        })
    });
};

;// CONCATENATED MODULE: ./components/Footer/index.tsx

function Footer() {
    return /*#__PURE__*/ jsx_runtime_.jsx("footer", {
        className: "container mx-auto",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "py-2 text-white px-4 bg-slate-800 mt-5 rounded-tl-xl rounded-tr-xl drop-shadow-xl",
            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "text-sm text-center block",
                children: "Copyright \xa9aldhipradana"
            })
        })
    });
};

// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
;// CONCATENATED MODULE: ./components/Layout/index.tsx




function Layout(props) {
    const { children , pageTitle  } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("title", {
                        children: [
                            "Aldhi Pradana | ",
                            pageTitle
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "Website pribadi milik Aldhi Pradana"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Header, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: children
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Footer, {})
                ]
            })
        ]
    });
};


/***/ })

};
;